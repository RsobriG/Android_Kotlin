package com.codigoroger.a02aboutme

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import com.codigoroger.a02aboutme.databinding.ActivityMainBinding



class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val myName: MyName = MyName( "Roger Sobrino")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        binding.myName = myName
       // findViewById<Button>(R.id.done_button).setOnClickListener{
       //     addNickname(it)
       // }

        binding.doneButton.setOnClickListener{
            addNickname(it)
        }
    }

    private fun addNickname(View: View){
        //val editText = findViewById<EditText>(R.id.nickname_edit)
        //val nicknameTextView = findViewById<TextView>(R.id.nickname_text)

        binding.apply {

            myName?.nickname = nicknameEdit.text.toString()
            //binding.nicknameText.text = binding.nicknameEdit.text
            invalidateAll()
            binding.nicknameEdit.visibility = android.view.View.GONE
            binding.doneButton.visibility = android.view.View.GONE
            binding.nicknameText.visibility = android.view.View.VISIBLE

        }

        //Hide the keyboard
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(View.windowToken, 0)

    }
}
