package com.codigoroger.a02aboutme

data class MyName (var name: String = "", var nickname: String = "")